import os
import cv2
import tempfile
import numpy as np
import streamlit as st
from tensorflow.keras.models import load_model

# -----------------------------
# PAGE CONFIG
# -----------------------------
st.set_page_config(
    page_title="AI Virtual Interviewer",
    page_icon="🎤",
    layout="wide"
)

# -----------------------------
# CUSTOM CSS
# -----------------------------
st.markdown(
    """
    <style>
    video {
        width: 380px !important;
        height: auto !important;
        border-radius: 16px;
        box-shadow: 0px 4px 15px rgba(0,0,0,0.2);
    }

    .main-title {
        font-size: 38px;
        font-weight: 700;
        margin-bottom: 5px;
    }

    .subtitle {
        font-size: 18px;
        color: #555;
        margin-bottom: 25px;
    }
    </style>
    """,
    unsafe_allow_html=True
)

# -----------------------------
# PATHS
# -----------------------------
MODEL_PATH = "models/best_cnn_frame_model.h5"

IMG_SIZE = 64
MAX_FRAMES = 20

# -----------------------------
# LOAD MODEL
# -----------------------------
@st.cache_resource
def load_cnn_model():
    return load_model(MODEL_PATH)

model = load_cnn_model()

# -----------------------------
# FRAME EXTRACTION
# -----------------------------
def extract_frames(video_path):

    cap = cv2.VideoCapture(video_path)
    frames = []

    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    if total_frames == 0:
        cap.release()
        return np.zeros((MAX_FRAMES, IMG_SIZE, IMG_SIZE, 3))

    frame_indices = np.linspace(
        0,
        total_frames - 1,
        MAX_FRAMES
    ).astype(int)

    for idx in frame_indices:

        cap.set(cv2.CAP_PROP_POS_FRAMES, idx)

        success, frame = cap.read()

        if success:

            # Resize
            frame = cv2.resize(
                frame,
                (IMG_SIZE, IMG_SIZE)
            )

            # BGR → RGB
            frame = cv2.cvtColor(
                frame,
                cv2.COLOR_BGR2RGB
            )

            # Normalize
            frame = frame / 255.0

            frames.append(frame)

        else:
            frames.append(
                np.zeros((IMG_SIZE, IMG_SIZE, 3))
            )

    cap.release()

    return np.array(frames)

# -----------------------------
# FEEDBACK FUNCTION
# -----------------------------
def generate_feedback(score):

    if score >= 85:

        confidence_feedback = "Excellent confidence and strong interview presence detected."

        communication_feedback = "Very strong communication behavior observed."

        behavior_feedback = "The candidate maintained stable visual engagement throughout the interview."

        recommendation = "Highly Recommended"

    elif score >= 70:

        confidence_feedback = "Good confidence level detected."

        communication_feedback = "Communication appears clear and professional."

        behavior_feedback = "The candidate showed consistent interview behavior."

        recommendation = "Recommended"

    elif score >= 50:

        confidence_feedback = "Average confidence level detected."

        communication_feedback = "Some hesitation or nervousness observed."

        behavior_feedback = "Behavioral consistency needs improvement."

        recommendation = "Needs Improvement"

    else:

        confidence_feedback = "Low confidence detected."

        communication_feedback = "Weak communication behavior observed."

        behavior_feedback = "Candidate needs improvement in presentation and confidence."

        recommendation = "Not Recommended"

    return (
        confidence_feedback,
        communication_feedback,
        behavior_feedback,
        recommendation
    )

# -----------------------------
# TITLE
# -----------------------------
st.markdown(
    '<div class="main-title">🎤 AI-Based Virtual Interviewer</div>',
    unsafe_allow_html=True
)

st.markdown(
    '<div class="subtitle">Upload an interview video for automated interview evaluation using Deep Learning.</div>',
    unsafe_allow_html=True
)

# -----------------------------
# VIDEO UPLOAD
# -----------------------------
uploaded_video = st.file_uploader(
    "Upload Interview Video",
    type=["mp4", "avi", "mov"]
)

if uploaded_video is not None:

    st.subheader("Uploaded Interview Video")

    st.video(uploaded_video)

# -----------------------------
# ANALYSIS BUTTON
# -----------------------------
if st.button("Analyze Interview"):

    if uploaded_video is None:

        st.error("Please upload a video first.")

    else:

        with st.spinner("Analyzing interview video..."):

            # Save temporary video
            temp_file = tempfile.NamedTemporaryFile(
                delete=False,
                suffix=".mp4"
            )

            temp_file.write(uploaded_video.read())

            temp_video_path = temp_file.name

            # Extract frames
            frames = extract_frames(temp_video_path)

            # Add batch dimension
            frames = np.expand_dims(frames, axis=0)

            # Prediction
            probability = model.predict(frames)[0][0]

            # Convert to percentage score
            score = float(probability) * 100

            # Final decision
            if score >= 70:
                decision = "Selected"
            else:
                decision = "Not Selected"

            # Feedback generation
            (
                confidence_feedback,
                communication_feedback,
                behavior_feedback,
                recommendation
            ) = generate_feedback(score)

        st.success("Interview analysis completed successfully.")

        # -----------------------------
        # FINAL RESULT
        # -----------------------------
        st.subheader("Final Interview Decision")

        col1, col2 = st.columns(2)

        with col1:

            if decision == "Selected":
                st.success(f"Decision: {decision}")

            else:
                st.error(f"Decision: {decision}")

        with col2:

            st.metric(
                "Interview Score",
                f"{round(score, 2)}%"
            )

        # -----------------------------
        # FEEDBACK SECTION
        # -----------------------------
        st.subheader("AI-Based Behavioral Feedback")

        st.write("### Confidence Analysis")
        st.info(confidence_feedback)

        st.write("### Communication Analysis")
        st.info(communication_feedback)

        st.write("### Behavioral Observation")
        st.info(behavior_feedback)

        st.write("### Final Recommendation")

        if recommendation in [
            "Highly Recommended",
            "Recommended"
        ]:

            st.success(recommendation)

        elif recommendation == "Needs Improvement":

            st.warning(recommendation)

        else:

            st.error(recommendation)

